-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 18, 2021 at 01:08 PM
-- Server version: 8.0.24
-- PHP Version: 8.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `order_drive`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int NOT NULL,
  `batch` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2021-05-12-103938', 'App\\Database\\Migrations\\AdminsCredential', 'default', 'App', 1636193461, 1),
(2, '2021-09-11-132930', 'App\\Database\\Migrations\\VendorManagement', 'default', 'App', 1636193462, 1),
(3, '2021-09-16-171250', 'App\\Database\\Migrations\\CategoryManagement', 'default', 'App', 1636193463, 1),
(4, '2021-09-19-132155', 'App\\Database\\Migrations\\ProductManagement', 'default', 'App', 1636193464, 1),
(5, '2021-11-06-074145', 'App\\Database\\Migrations\\Orders', 'default', 'App', 1636193465, 1),
(6, '2021-11-06-074201', 'App\\Database\\Migrations\\Payment', 'default', 'App', 1636193465, 1);

-- --------------------------------------------------------

--
-- Table structure for table `od_admins_credential`
--

CREATE TABLE `od_admins_credential` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `passkey` varchar(255) NOT NULL,
  `active_status` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `od_admins_credential`
--

INSERT INTO `od_admins_credential` (`id`, `name`, `email`, `passkey`, `active_status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Md. Farzan', 'mdfarzan776@gmail.com', '$2y$10$384cZkz.dRiKPTuBaNSZv.rkcvCH.B8XuxP..AonYTjE0GtCkzokm', 1, NULL, '2021-11-06 15:41:53', '2021-11-06 15:41:53');

-- --------------------------------------------------------

--
-- Table structure for table `od_admin_privileges`
--

CREATE TABLE `od_admin_privileges` (
  `admin_id` int UNSIGNED NOT NULL,
  `category_management` tinyint(1) NOT NULL,
  `product_management` tinyint(1) NOT NULL,
  `vendor_management` tinyint(1) NOT NULL,
  `admins_management` tinyint(1) NOT NULL,
  `order_management` tinyint(1) NOT NULL,
  `report_management` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `od_admin_privileges`
--

INSERT INTO `od_admin_privileges` (`admin_id`, `category_management`, `product_management`, `vendor_management`, `admins_management`, `order_management`, `report_management`) VALUES
(1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `od_orders`
--

CREATE TABLE `od_orders` (
  `id` int UNSIGNED NOT NULL,
  `vendor_id` int UNSIGNED NOT NULL,
  `ref_no` varchar(255) NOT NULL,
  `product_ids` varchar(255) NOT NULL,
  `product_qtys` varchar(255) NOT NULL,
  `product_prices` varchar(255) NOT NULL,
  `delivery_address` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `order_status` int NOT NULL,
  `order_date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `od_orders`
--

INSERT INTO `od_orders` (`id`, `vendor_id`, `ref_no`, `product_ids`, `product_qtys`, `product_prices`, `delivery_address`, `order_status`, `order_date`) VALUES
(15, 1, '', '4,3,2', '1,1,1', '135,330,525', 'Inder Lok', 1, '2021-11-06 20:00:49'),
(16, 1, '', '4,3,2', '1,1,1', '135,330,525', 'Inder Lok', 0, '2021-11-06 20:03:23'),
(17, 1, '', '4,3,2', '1,1,1', '135,330,525', 'Inder Lok', 1, '2021-11-06 20:06:59'),
(18, 1, '', '4,3,2', '1,1,1', '135,330,525', 'Inder Lok', 4, '2021-11-06 20:07:25'),
(19, 1, '', '5,4,3,2', '1,1,1,1', '650,135,330,525', 'Haryana', 2, '2021-11-06 20:08:14'),
(20, 1, '', '5,4,3,2', '2,3,2,5', '650,135,330,525', 'UP', 2, '2021-11-06 20:29:27'),
(21, 1, 'OD-170621-356a1', '5,4,2', '2,3,5', '650,135,525', 'adfads', 2, '2021-11-06 20:31:34'),
(22, 1, 'OD-180621-da4b9', '5', '2', '650', 'jhjh', 2, '2021-11-06 20:33:16'),
(23, 1, 'OD-190621-da4b9', '5', '3', '650', 'Paata', 2, '2021-11-06 20:33:53'),
(24, 1, 'OD-1100621-77de6', '2,5', '1,3', '525,650', 'ASJDLASD', 2, '2021-11-06 20:37:11'),
(25, 1, 'OD-1110621-da4b9', '2,5', '1,3', '525,650', 'lakjsdlf', 2, '2021-11-06 20:46:42'),
(26, 1, 'OD-1120621-902ba', '5', '3', '650', 'sdsd', 2, '2021-11-06 20:47:56'),
(27, 1, 'OD-1130621-b1d57', '5', '3', '650', 'fdfsdf', 2, '2021-11-06 20:48:51'),
(28, 1, 'OD-1140621-c1dfd', '5', '3', '650', 'fdfsdf', 3, '2021-11-06 20:56:24'),
(29, 1, 'OD-1150621-77de6', '2', '2', '525', 'Shastri Nagar', 4, '2021-11-06 20:57:22'),
(30, 1, 'OD-1160621-b1d57', '2', '1', '525', 'asdfas', 4, '2021-11-06 21:01:01'),
(31, 1, 'OD-1160621-356a1', '1,2', '1,1', '443,525', 'Test', 0, '2021-11-07 08:44:58'),
(32, 1, 'OD-1171221-c1dfd', '2,5', '1,1', '525,650', 'Test 2', 0, '2021-11-13 11:29:36');

-- --------------------------------------------------------

--
-- Table structure for table `od_payments`
--

CREATE TABLE `od_payments` (
  `id` int UNSIGNED NOT NULL,
  `vendor_id` int UNSIGNED NOT NULL,
  `payment_mode` varchar(225) NOT NULL,
  `payble_amt` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `od_payments`
--

INSERT INTO `od_payments` (`id`, `vendor_id`, `payment_mode`, `payble_amt`) VALUES
(15, 1, 'cash', 990),
(16, 1, 'cash', 990),
(17, 1, 'cash', 990),
(18, 1, 'cash', 990),
(19, 1, 'cash', 1640),
(20, 1, 'cash', 4990),
(21, 1, 'cash', 4330),
(22, 1, 'card', 1300),
(23, 1, 'upi', 1950),
(24, 1, 'upi', 2475),
(25, 1, 'cash', 2475),
(26, 1, 'cash', 1950),
(27, 1, 'cash', 1950),
(28, 1, 'cash', 1950),
(29, 1, 'cash', 1050),
(30, 1, 'upi', 525),
(31, 1, 'cash', 968),
(32, 1, 'cash', 1175);

-- --------------------------------------------------------

--
-- Table structure for table `od_products`
--

CREATE TABLE `od_products` (
  `id` int UNSIGNED NOT NULL,
  `category_id` int UNSIGNED NOT NULL,
  `thumbnail_src` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `short_desc` text,
  `long_desc` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `od_products`
--

INSERT INTO `od_products` (`id`, `category_id`, `thumbnail_src`, `name`, `price`, `short_desc`, `long_desc`) VALUES
(1, 3, 'uploads/ef7af1251c0aea04bda6db47175a3de4.jpg', 'Faded Mens Grey Denim Jeans', 443, '<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Waist Size</td>\r\n			<td>All Sizes</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Brand</td>\r\n			<td>Denim</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Pattern</td>\r\n			<td>Faded</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>mens grey slim fit snitch washed jeans.</p>\r\n', '<h3>Product Specification</h3>\r\n\r\n<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Waist Size</td>\r\n			<td>All Sizes</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Brand</td>\r\n			<td>Denim</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Pattern</td>\r\n			<td>Faded</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<h3>Product Description</h3>\r\n\r\n<p>mens grey slim fit snitch washed jeans.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n'),
(2, 3, 'uploads/106271813f26ac6234fc732afb5045f3.jpeg', 'Boys Comfort Fit Jeans', 525, '<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Fit Type</td>\r\n			<td>Comfort Fit</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Color</td>\r\n			<td>All</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Gender</td>\r\n			<td>Boys</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Wash Care</td>\r\n			<td>Handwash</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Occasion</td>\r\n			<td>Casual Wear</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Country of Origin</td>\r\n			<td>Made in India</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '<h3>Product Specification</h3>\r\n\r\n<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Fit Type</td>\r\n			<td>Comfort Fit</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Color</td>\r\n			<td>All</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Gender</td>\r\n			<td>Boys</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Wash Care</td>\r\n			<td>Handwash</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Occasion</td>\r\n			<td>Casual Wear</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Country of Origin</td>\r\n			<td>Made in India</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n'),
(3, 2, 'uploads/a18577e6be7d1f829fb2ff71b78dbd43.jpg', 'Plain Full Sleeves Blue Bond Denim Shirt', 330, '<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Fabric</td>\r\n			<td>Denim</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Pattern</td>\r\n			<td>Plain</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Size</td>\r\n			<td>All size</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Sleeves Type</td>\r\n			<td>Full Sleeves</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Minimum Order Quantity</td>\r\n			<td>50 Piece</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '<h3>Product Specification</h3>\r\n\r\n<p>1 set = 50 Jeans</p>\r\n\r\n<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Fabric</td>\r\n			<td>Denim</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Pattern</td>\r\n			<td>Plain</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Size</td>\r\n			<td>All size</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Sleeves Type</td>\r\n			<td>Full Sleeves</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Minimum Order Quantity</td>\r\n			<td>50 Piece</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<h3>Product Description</h3>\r\n\r\n<p>*bluebond *denim shirts original 100%cotton denim shirts &#39;! High quality &#39;fabric &#39; fit = slim fit premium mill made bio finish fabric shade = 10 sizes s m l xl xxl ratio = 1 1 111 5pcs price =330 high quality 100% cotton lenin premium wash min moq = 50 pcs? ?&nbsp; goods ready for despatch&nbsp;</p>\r\n'),
(4, 4, 'uploads/360c30d2aeff9b5daad95910e147119c.JPG', 'Cotton Vimal Jonney Black Full Sleeve Hoodie T Shirt For Men', 135, '<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Product Type</td>\r\n			<td>T SHIRT</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Brand</td>\r\n			<td>VIMAL</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Color</td>\r\n			<td>Black</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Size</td>\r\n			<td>S,M,L,XL,XXL</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Fabric</td>\r\n			<td>Cotton</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Neck Type</td>\r\n			<td>HOODED NECK</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '<h3>Product Specification</h3>\r\n\r\n<p>1 set = 50 T-Shirts</p>\r\n\r\n<p>Single set have 10 pcs. of each availabe size.</p>\r\n\r\n<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Product Type</td>\r\n			<td>T SHIRT</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Brand</td>\r\n			<td>VIMAL</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Color</td>\r\n			<td>Black</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Size</td>\r\n			<td>S,M,L,XL,XXL</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Fabric</td>\r\n			<td>Cotton</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Neck Type</td>\r\n			<td>HOODED NECK</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Gender</td>\r\n			<td>Men</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Sleeve Type</td>\r\n			<td>Full Sleeves</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Neck</td>\r\n			<td>HOODED NECK</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<h3>Product Description</h3>\r\n\r\n<p>Patriot is not just a brand, it is an emotion. A belonging to the nation, the soul, India. This t-shirt has been designed using the fabric that is lightweight and strong, fit for the battlefield called life! 100% Premium Cotton, 180 GSM, and strong colour will ensure it lasts, and it will!</p>\r\n'),
(5, 5, 'uploads/de6d1cc78a654cf10124e86c2d4f114f.jpg', 'Full Sleeve Casual Wear RFD JACKETS', 650, '<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Jacket Type</td>\r\n			<td>Casual Jackets</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Sleeves Type</td>\r\n			<td>Full Sleeve</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Color</td>\r\n			<td>Black</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Occasion</td>\r\n			<td>Casual Wear</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '<h3>Product Specification</h3>\r\n\r\n<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Jacket Type</td>\r\n			<td>Casual Jackets</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Sleeves Type</td>\r\n			<td>Full Sleeve</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Color</td>\r\n			<td>Black</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Occasion</td>\r\n			<td>Casual Wear</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `od_product_categories`
--

CREATE TABLE `od_product_categories` (
  `id` int UNSIGNED NOT NULL,
  `p_id` int UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `od_product_categories`
--

INSERT INTO `od_product_categories` (`id`, `p_id`, `name`, `slug`) VALUES
(1, 0, 'Jeans', 'jeans'),
(2, 1, 'Jeans Shirt', 'jeans-shirt'),
(3, 1, 'Jeans Pants', 'jeans-pants'),
(4, 0, 'T-Shirt', 't-shirt'),
(5, 0, 'Jackets', 'jackets'),
(6, 0, 'Sweaters', 'sweaters'),
(7, 0, 'Shoes', 'shoes'),
(8, 0, 'Lowers', 'lowers');

-- --------------------------------------------------------

--
-- Table structure for table `od_product_gallery`
--

CREATE TABLE `od_product_gallery` (
  `id` int UNSIGNED NOT NULL,
  `product_id` int UNSIGNED NOT NULL,
  `img_src` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `od_vendor_credentials`
--

CREATE TABLE `od_vendor_credentials` (
  `id` int UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `passkey` varchar(255) NOT NULL,
  `active_status` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `od_vendor_credentials`
--

INSERT INTO `od_vendor_credentials` (`id`, `email`, `passkey`, `active_status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'vendor@gmail.com', '$2y$10$mo19oJ39WrNnlGmqa6L6pej6dJaFsS51hTLrMe5rUiOAKFLO..4uu', 1, NULL, '2021-11-06 05:36:40', '2021-11-06 05:36:40');

-- --------------------------------------------------------

--
-- Table structure for table `od_vendor_profile`
--

CREATE TABLE `od_vendor_profile` (
  `vendor_id` int UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `primary_address` varchar(255) NOT NULL,
  `secondary_address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `od_vendor_profile`
--

INSERT INTO `od_vendor_profile` (`vendor_id`, `name`, `contact_no`, `primary_address`, `secondary_address`) VALUES
(1, 'Vendor', '8750611500', 'Inder Lok', 'Shastri Nagar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `od_admins_credential`
--
ALTER TABLE `od_admins_credential`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `od_admin_privileges`
--
ALTER TABLE `od_admin_privileges`
  ADD KEY `OD_admin_privileges_admin_id_foreign` (`admin_id`);

--
-- Indexes for table `od_orders`
--
ALTER TABLE `od_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `od_payments`
--
ALTER TABLE `od_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `od_products`
--
ALTER TABLE `od_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `od_product_categories`
--
ALTER TABLE `od_product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `od_product_gallery`
--
ALTER TABLE `od_product_gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `OD_product_gallery_product_id_foreign` (`product_id`);

--
-- Indexes for table `od_vendor_credentials`
--
ALTER TABLE `od_vendor_credentials`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `od_vendor_profile`
--
ALTER TABLE `od_vendor_profile`
  ADD KEY `OD_vendor_profile_vendor_id_foreign` (`vendor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `od_admins_credential`
--
ALTER TABLE `od_admins_credential`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `od_orders`
--
ALTER TABLE `od_orders`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `od_products`
--
ALTER TABLE `od_products`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `od_product_categories`
--
ALTER TABLE `od_product_categories`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `od_vendor_credentials`
--
ALTER TABLE `od_vendor_credentials`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `od_admin_privileges`
--
ALTER TABLE `od_admin_privileges`
  ADD CONSTRAINT `OD_admin_privileges_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `od_admins_credential` (`id`);

--
-- Constraints for table `od_payments`
--
ALTER TABLE `od_payments`
  ADD CONSTRAINT `OD_payments_id_foreign` FOREIGN KEY (`id`) REFERENCES `od_orders` (`id`);

--
-- Constraints for table `od_product_gallery`
--
ALTER TABLE `od_product_gallery`
  ADD CONSTRAINT `OD_product_gallery_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `od_products` (`id`);

--
-- Constraints for table `od_vendor_profile`
--
ALTER TABLE `od_vendor_profile`
  ADD CONSTRAINT `OD_vendor_profile_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `od_vendor_credentials` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
